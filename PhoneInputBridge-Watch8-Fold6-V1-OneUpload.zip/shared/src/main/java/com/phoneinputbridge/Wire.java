package com.phoneinputbridge;
import android.content.Context;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
final class Wire {
 static final String REQ="/pib/request", READY="/pib/ready", SEND="/pib/send", ACK="/pib/ack", CLOSE="/pib/close";
 static final int MAX=12000;
 static final long TTL=180000L;
 static JSONObject packet(String id, String... kv) { JSONObject j=new JSONObject(); try {j.put("id",id);for(int i=0;i<kv.length;i+=2)j.put(kv[i],kv[i+1]);}catch(Exception e){throw new IllegalArgumentException(e);}return j; }
 static JSONObject read(byte[] b){try{if(b.length>60000)return null;return new JSONObject(new String(b,StandardCharsets.UTF_8));}catch(Exception e){return null;}}
 static Task<Integer> send(Context c,String node,String path,JSONObject j){return Wearable.getMessageClient(c).sendMessage(node,path,j.toString().getBytes(StandardCharsets.UTF_8));}
}
