package com.phoneinputbridge;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
final class Ui {
 static final int GREEN=0xff86dca5, GRAY=0xffaaaaaa, WHITE=0xffeeeeee;
 static int dp(Context c,float x){return (int)(x*c.getResources().getDisplayMetrics().density+.5f);}
 static GradientDrawable bg(Context c,int color,int edge,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));d.setStroke(dp(c,1),edge);return d;}
 static TextView text(Context c,String s,int size,int color){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);return t;}
 static Button button(Context c,String s,boolean primary){Button b=new Button(c);b.setText(s);b.setTextSize(14);b.setAllCaps(false);b.setTextColor(primary?GREEN:WHITE);b.setBackground(bg(c,Color.BLACK,primary?GREEN:0xff646464,28));b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(dp(c,5),0,dp(c,5),0);return b;}
 static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER_HORIZONTAL);l.setBackgroundColor(Color.BLACK);return l;}
 static void add(LinearLayout l,android.view.View v,int height,int margin){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,height<0?height:dp(l.getContext(),height));p.topMargin=dp(l.getContext(),margin);l.addView(v,p);}
}
