package com.phoneinputbridge;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.text.InputFilter;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import com.google.android.gms.wearable.Wearable;
import java.util.UUID;
public class PhoneActivity extends Activity {
 private TextView state;private EditText edit;private Button insert,done;private String session,tx,mode,payload;private boolean sending;private final Handler handler=new Handler(Looper.getMainLooper());
 private final Runnable tick=new Runnable(){public void run(){refresh(false);handler.postDelayed(this,1000);}};
 private final BroadcastReceiver changes=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String ack=i.getStringExtra("tx");if(ack!=null&&ack.equals(tx)&&session!=null&&session.equals(i.getStringExtra("id"))){sending=false;handler.removeCallbacks(failed);boolean ok="1".equals(i.getStringExtra("ok"));if(ok){tx=null;payload=null;mode=null;edit.setText("");state.setText("✓ 手表已收到文字");}else{tx=null;payload=null;mode=null;state.setText("手表未能填入，请重试");}buttons();}else if(ack==null)refresh(true);}};
 private final Runnable failed=()->{if(sending){sending=false;state.setText("未收到确认；重试将使用同一请求，避免重复输入");buttons();}};
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);PhoneListener.channel(this);
 ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout l=Ui.column(this);int p=Ui.dp(this,20);l.setPadding(p,p,p,p);sc.addView(l);setContentView(sc);
 TextView title=Ui.text(this,"手表远程输入",26,Ui.WHITE);Ui.add(l,title,48,0);state=Ui.text(this,"等待手表输入请求",15,Ui.GREEN);Ui.add(l,state,-2,8);
 edit=new EditText(this);edit.setTextColor(Ui.WHITE);edit.setHintTextColor(Ui.GRAY);edit.setHint("在这里输入文字，支持中文、网址、语音及粘贴");edit.setTextSize(20);edit.setGravity(Gravity.TOP|Gravity.START);edit.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(Wire.MAX)});edit.setPadding(p,p,p,p);edit.setBackground(Ui.bg(this,0xff101010,0xff555555,12));edit.setMinLines(3);edit.setMaxLines(5);edit.setSaveEnabled(false);Ui.add(l,edit,-2,16);
 insert=Ui.button(this,"发送到手表（继续输入）",true);Ui.add(l,insert,52,12);insert.setOnClickListener(v->send("insert"));done=Ui.button(this,"发送并确认",true);Ui.add(l,done,52,8);done.setOnClickListener(v->send("done"));
 Button paste=Ui.button(this,"粘贴剪贴板",false);Ui.add(l,paste,44,8);paste.setOnClickListener(v->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm.hasPrimaryClip()&&cm.getPrimaryClip()!=null){CharSequence s=cm.getPrimaryClip().getItemAt(0).coerceToText(this);if(s!=null)edit.getText().replace(Math.max(0,edit.getSelectionStart()),Math.max(0,edit.getSelectionEnd()),s);}});
 Button clear=Ui.button(this,"清空 / 放弃未确认的重试",false);Ui.add(l,clear,44,8);clear.setOnClickListener(v->{if(sending)return;if(tx!=null){new AlertDialog.Builder(this).setMessage("上一笔输入可能已到达手表。请先查看手表，确认后再重新输入。") .setNegativeButton("取消",null).setPositiveButton("放弃重试",(d,w)->{tx=null;mode=null;payload=null;edit.setText("");buttons();}).show();}else edit.setText("");});
 Ui.add(l,Ui.text(this,"手表点击输入框 → 手机收到通知 → 在此输入。密码框请使用手表原生键盘。",13,Ui.GRAY),-2,16);
 Button perm=Ui.button(this,"开启通知 / 检查连接",false);Ui.add(l,perm,44,10);perm.setOnClickListener(v->{permissions();checkConnection();});
 l.setFocusableInTouchMode(true);l.requestFocus();permissions();refresh(getIntent().getBooleanExtra("open",false));}
 private void permissions(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},13);}
 private void checkConnection(){Wearable.getNodeClient(this).getConnectedNodes().addOnSuccessListener(nodes->{boolean near=false;for(com.google.android.gms.wearable.Node n:nodes)if(n.isNearby())near=true;Toast.makeText(this,near?"已检测到近距离 Wear OS 设备":"未检测到近距离手表",Toast.LENGTH_SHORT).show();}).addOnFailureListener(e->Toast.makeText(this,"连接检查失败",Toast.LENGTH_SHORT).show());}
 @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);refresh(i.getBooleanExtra("open",false));}
 @Override protected void onStart(){super.onStart();IntentFilter f=new IntentFilter(PhoneListener.CHANGE);if(Build.VERSION.SDK_INT>=33)registerReceiver(changes,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(changes,f);refresh(false);handler.post(tick);}
 @Override protected void onStop(){handler.removeCallbacks(tick);unregisterReceiver(changes);super.onStop();}
 @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
 private void refresh(boolean focus){PhoneListener.Session s=PhoneListener.current(this);String next=s==null?null:s.id;boolean changed=!java.util.Objects.equals(session,next);if(changed){session=next;tx=null;mode=null;payload=null;sending=false;handler.removeCallbacks(failed);edit.setText("");state.setText(session==null?"等待手表输入请求":"● 手表输入框已就绪");}else if(session==null)state.setText("等待手表输入请求");buttons();if(session!=null&&(focus||changed)){edit.requestFocus();edit.postDelayed(()->{if(edit.hasFocus()&&session!=null)((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(edit,InputMethodManager.SHOW_IMPLICIT);},250);}}
 private void buttons(){boolean ready=session!=null&&!sending;insert.setEnabled(ready&&(tx==null||"insert".equals(mode)));done.setEnabled(ready&&(tx==null||"done".equals(mode)));edit.setEnabled(ready&&tx==null);}
 private void send(String requested){PhoneListener.Session s=PhoneListener.current(this);if(s==null||!s.id.equals(session)){refresh(false);return;}if(sending)return;if(tx==null){payload=edit.getText().toString();if(payload.isEmpty()&&requested.equals("insert"))return;mode=requested;tx=UUID.randomUUID().toString();}else if(!requested.equals(mode))return;String currentTx=tx;String currentSession=session;sending=true;buttons();state.setText("正在等待手表确认…");handler.removeCallbacks(failed);handler.postDelayed(failed,6000);Wearable.getNodeClient(this).getConnectedNodes().addOnSuccessListener(nodes->{if(!currentTx.equals(tx)||!currentSession.equals(session)||!sending)return;boolean nearby=false;for(com.google.android.gms.wearable.Node n:nodes)if(n.getId().equals(s.node)&&n.isNearby())nearby=true;if(!nearby){failed.run();return;}Wire.send(this,s.node,Wire.SEND,Wire.packet(s.id,"tx",tx,"text",payload,"mode",mode)).addOnFailureListener(e->{if(currentTx.equals(tx)&&currentSession.equals(session))failed.run();});}).addOnFailureListener(e->{if(currentTx.equals(tx)&&currentSession.equals(session))failed.run();});}
}
