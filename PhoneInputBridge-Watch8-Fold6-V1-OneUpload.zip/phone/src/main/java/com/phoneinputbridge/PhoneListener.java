package com.phoneinputbridge;
import android.app.*;
import android.content.*;
import android.os.*;
import com.google.android.gms.wearable.*;
import org.json.JSONObject;
public class PhoneListener extends WearableListenerService {
 static final String CHANNEL="input_requests", CHANGE="com.phoneinputbridge.CHANGE";
 static final int NOTIFICATION=812;
 static final class Session {final String id,node;final long expires;Session(String i,String n,long t){id=i;node=n;expires=t;}}
 static Session current(Context c){android.content.SharedPreferences p=c.getSharedPreferences("session",0);String id=p.getString("id","");long t=p.getLong("expires",0);return id.isEmpty()||SystemClock.elapsedRealtime()>t?null:new Session(id,p.getString("node",""),t);}
 static void notifyChange(Context c){c.sendBroadcast(new Intent(CHANGE).setPackage(c.getPackageName()));}
 static void channel(Context c){NotificationManager n=c.getSystemService(NotificationManager.class);NotificationChannel ch=new NotificationChannel(CHANNEL,"手表文字输入请求",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("点击通知使用手机键盘输入");n.createNotificationChannel(ch);}
 @Override public void onMessageReceived(MessageEvent e){JSONObject j=Wire.read(e.getData());if(j==null)return;String id=j.optString("id"),node=e.getSourceNodeId();if(id.length()!=36)return;String path=e.getPath();Session s=current(this);
 if(Wire.REQ.equals(path)){getSharedPreferences("session",0).edit().putString("id",id).putString("node",node).putLong("expires",SystemClock.elapsedRealtime()+Wire.TTL).apply();Wire.send(this,node,Wire.READY,Wire.packet(id));channel(this);Intent intent=new Intent(this,PhoneActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("open",true);PendingIntent pi=PendingIntent.getActivity(this,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_dialog_email).setContentTitle("手表需要输入文字").setContentText("点击使用手机键盘").setContentIntent(pi).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setTimeoutAfter(Wire.TTL).setOnlyAlertOnce(true).build();if(Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED)getSystemService(NotificationManager.class).notify(NOTIFICATION,n);notifyChange(this);}
 else if(s!=null&&s.id.equals(id)&&s.node.equals(node)){if(Wire.CLOSE.equals(path)){getSharedPreferences("session",0).edit().clear().apply();getSystemService(NotificationManager.class).cancel(NOTIFICATION);notifyChange(this);}else if(Wire.ACK.equals(path)){Intent i=new Intent(CHANGE).setPackage(getPackageName()).putExtra("id",id).putExtra("tx",j.optString("tx")).putExtra("ok",j.optString("ok")).putExtra("mode",j.optString("mode"));sendBroadcast(i);}}
 }
}
