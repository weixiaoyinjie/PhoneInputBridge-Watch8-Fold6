package com.phoneinputbridge;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
public class SetupActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);ScrollView scroll=new ScrollView(this);LinearLayout l=Ui.column(this);int p=Ui.dp(this,24);l.setPadding(p,p,p,p);scroll.addView(l);setContentView(scroll);
 Ui.add(l,Ui.text(this,"手机远程输入",18,Ui.GREEN),-2,0);
 Ui.add(l,Ui.text(this,"先启用输入法，再选择为当前键盘。手机端需安装同批 APK。",13,Ui.GRAY),-2,6);
 Button enable=Ui.button(this,"① 启用输入法",true);Ui.add(l,enable,38,8);enable.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
 Button pick=Ui.button(this,"② 选择输入法",true);Ui.add(l,pick,38,6);pick.setOnClickListener(v->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
 EditText test=new EditText(this);test.setSingleLine(true);test.setHint("点击测试");test.setTextColor(Ui.WHITE);Ui.add(l,test,42,7);
 }
}
