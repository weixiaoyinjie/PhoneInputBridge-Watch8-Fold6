package com.phoneinputbridge;
import android.inputmethodservice.InputMethodService;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.view.inputmethod.*;
import android.widget.*;
import com.google.android.gms.wearable.*;
import org.json.JSONObject;
import java.util.*;
public class BridgeIme extends InputMethodService implements MessageClient.OnMessageReceivedListener {
 private final Handler main=new Handler(Looper.getMainLooper());
 private String session,phone; private long expires; private boolean active,blocked; private TextView status; private Button request;
 private final Set<String> offered=new HashSet<>(); private final Map<String,JSONObject> replies=new HashMap<>();
 private final Runnable timeout=()->{end();say("输入请求已过期，请重试");};
 @Override public void onCreate(){super.onCreate();Wearable.getMessageClient(this).addListener(this);}
 @Override public boolean onEvaluateFullscreenMode(){return true;}
 @Override public View onCreateExtractTextView(){View v=super.onCreateExtractTextView();return v;}
 @Override public View onCreateInputView(){LinearLayout l=Ui.column(this);int p=Ui.dp(this,26);l.setPadding(p,Ui.dp(this,3),p,Ui.dp(this,6));
 status=Ui.text(this,"手机远程输入",13,Ui.GREEN);Ui.add(l,status,30,0);
 request=Ui.button(this,"手机输入 / 重试",true);Ui.add(l,request,34,3);request.setOnClickListener(v->begin());
 LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
 Button del=Ui.button(this,"删除",false),done=Ui.button(this,"确认",false);row.addView(del,new LinearLayout.LayoutParams(0,Ui.dp(this,32),1));LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,Ui.dp(this,32),1);q.leftMargin=Ui.dp(this,4);row.addView(done,q);Ui.add(l,row,32,4);
 del.setOnClickListener(v->{if(blocked)return;InputConnection ic=getCurrentInputConnection();if(ic!=null){CharSequence s=ic.getSelectedText(0);if(s!=null&&s.length()>0)ic.commitText("",1);else ic.deleteSurroundingTextInCodePoints(1,0);}});
 done.setOnClickListener(v->{if(!blocked)finishEditor();else switchKeyboard();});
 Button fallback=Ui.button(this,"切换本机键盘",false);Ui.add(l,fallback,32,4);fallback.setOnClickListener(v->switchKeyboard());return l;}
 @Override public void onStartInput(EditorInfo info,boolean restarting){super.onStartInput(info,restarting);if(!restarting)end();blocked=sensitive(info);}
 @Override public void onStartInputView(EditorInfo info,boolean restarting){super.onStartInputView(info,restarting);active=true;blocked=sensitive(info);if(request!=null)request.setEnabled(!blocked);if(blocked){end();say("安全输入框：请切换本机键盘");setCandidatesViewShown(false);setExtractViewShown(false);}else {setExtractViewShown(true);if(session==null)begin();}}
 @Override public void onFinishInputView(boolean finishingInput){active=false;end();super.onFinishInputView(finishingInput);}
 @Override public void onFinishInput(){active=false;end();super.onFinishInput();}
 @Override public void onDestroy(){active=false;end();Wearable.getMessageClient(this).removeListener(this);super.onDestroy();}
 private boolean sensitive(EditorInfo e){if(e==null||e.inputType==0)return true;int cl=e.inputType&InputType.TYPE_MASK_CLASS,v=e.inputType&InputType.TYPE_MASK_VARIATION;return (cl==InputType.TYPE_CLASS_TEXT&&(v==InputType.TYPE_TEXT_VARIATION_PASSWORD||v==InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD||v==InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD))||(cl==InputType.TYPE_CLASS_NUMBER&&v==InputType.TYPE_NUMBER_VARIATION_PASSWORD)||(e.imeOptions&EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING)!=0;}
 private void say(String s){if(status!=null)status.setText(s);}
 private void switchKeyboard(){end();((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker();}
 private void end(){main.removeCallbacks(timeout);String old=session;session=null;phone=null;replies.clear();if(old!=null)for(String n:new HashSet<>(offered))Wire.send(this,n,Wire.CLOSE,Wire.packet(old));offered.clear();if(getWindow()!=null&&getWindow().getWindow()!=null)getWindow().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
 private void begin(){if(!active||blocked||getCurrentInputConnection()==null)return;end();session=UUID.randomUUID().toString();String id=session;expires=SystemClock.elapsedRealtime()+Wire.TTL;main.postDelayed(timeout,Wire.TTL);if(getWindow()!=null&&getWindow().getWindow()!=null)getWindow().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);say("正在寻找手机…");
 Wearable.getNodeClient(this).getConnectedNodes().addOnSuccessListener(nodes->{if(!id.equals(session))return;for(Node n:nodes)if(n.isNearby()){offered.add(n.getId());Wire.send(this,n.getId(),Wire.REQ,Wire.packet(id)).addOnFailureListener(e->{if(id.equals(session)&&phone==null)say("发送失败，请重试");});}say(offered.isEmpty()?"手机未近距离连接":"请在手机打开输入通知");}).addOnFailureListener(e->{if(id.equals(session))say("连接失败，请重试");});}
 @Override public void onMessageReceived(MessageEvent e){String path=e.getPath(),node=e.getSourceNodeId();JSONObject j=Wire.read(e.getData());if(j!=null)main.post(()->receive(path,node,j));}
 private void receive(String path,String node,JSONObject j){String id=j.optString("id");if(!active||blocked||session==null||!session.equals(id)||SystemClock.elapsedRealtime()>expires||!offered.contains(node))return;
 if(Wire.READY.equals(path)){if(phone==null||phone.equals(node)){phone=node;say("手机已连接，等待输入");}return;}
 if(!Wire.SEND.equals(path)||(phone!=null&&!phone.equals(node)))return;phone=node;String tx=j.optString("tx"),text=j.optString("text"),mode=j.optString("mode");if(tx.isEmpty()||text.length()>Wire.MAX||(!mode.equals("insert")&&!mode.equals("done")))return;
 if(replies.containsKey(tx)){Wire.send(this,node,Wire.ACK,replies.get(tx));return;}if(replies.size()>=100)return;
 InputConnection ic=getCurrentInputConnection();boolean ok=false;if(ic!=null){try{ok=text.isEmpty()?mode.equals("done"):ic.commitText(text,1);}catch(RuntimeException ignored){}}
 JSONObject ack=Wire.packet(id,"tx",tx,"ok",ok?"1":"0","mode",mode);replies.put(tx,ack);Wire.send(this,node,Wire.ACK,ack);say(ok?"文字已填入":"输入失败，请重试");if(ok&&mode.equals("done")){main.postDelayed(()->{if(id.equals(session)&&active)finishEditor();},350);}}
 private void finishEditor(){if(getCurrentInputConnection()!=null){if(!sendDefaultEditorAction(true))sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);}requestHideSelf(0);end();}
}
